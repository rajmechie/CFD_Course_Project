data1=load("Analytical_solution_10.dat");
data2=load("Numerical_solution_weighted_jacobi_10.dat");
data3=load("Numerical_solution_gauss_siedel_10.dat");
data4=load("Numerical_solution_v_cycle_10.dat");
figure(1)
plot(data1(:,1),data1(:,2),Marker="*",LineStyle="none");
hold on
plot(data2(:,1),data2(:,2));
plot(data3(:,1),data3(:,2));
plot(data4(:,1),data4(:,2));
title("Solution of 1D Model Problem for k = 10");
xlabel("x");
ylabel("u");
legend("Analytical","Weighted-Jacobi","Gauss-Siedel","V-Cycle");
data5=load("iterations_vs_residual_2_norm_weighted_jacobi_10.dat");
data6=load("iterations_vs_residual_2_norm_gauss_siedel_10.dat");
data7=load("iterations_vs_residual_2_norm_v_cycle_10.dat");
figure(2)
plot(log10(data5(:,1)),log10(data5(:,2)));
hold on
plot(log10(data6(:,1)),log10(data6(:,2)));
plot(log10(data7(:,1)),log10(data7(:,2)));
title("Residual Norm vs Number of Iterations(Log-Log Plot)");
xlabel("Number of iterations");
ylabel("Residual norm");
legend("Weighted-Jacobi","Gauss-Siedel","V-Cycle");