#include <cmath>
#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

#define n 512 //Number of grid points in finest grid after 0 grid point
#define omega 2.0/ 3.0 //Omega for weighted Jacobi Method
#define nu1 2 //Number of iterations in forward phase of V-cycle
#define nu2 2 //Number of iterations in backward phase of V-cycle
#define sigma 1
#define pi 3.141592654
#define k 1 // 1 or 10
#define MaxIter 10000000
#define Tol 0.000001

// Class of Grid Level
class Level 
{ 
public:
    vector<double> u, v, e, f, r;
    int nl;
    double h;
    void set_level_gridpoints(int L, int l)
    {
        nl = pow(2, L - l);
        h = 1.0 / nl;
    }
    
    // Function to initialize the values of the vectors u, v, e, f, r
    void initialize()
    {
        if (nl == n)
        {
            u.resize(nl + 1, 0.0);
        }
        v.resize(nl + 1, 0.0);
        e.resize(nl + 1, 0.0);
        f.resize(nl + 1, 0.0);
        r.resize(nl + 1, 0.0);
    }
    void boundary_conditions()
    {
        v[0] = v[nl] = 0.0;
    }
    void calculate_f(double C)
    {
        int i;
        for (i = 1; i < nl; i ++)
        {
            f[i] = C * sin(k * pi * i * h);
        }
    }
    void analytical_solution()
    {
        int i;
        for (i = 1; i < nl; i ++)
        {
            u[i] = sin(k * pi * i * h);
        }
    }
    void v_weighted_jacobi()
    {
        double V;
        vector<double> v_new(nl + 1);
        int i;
        for (i = 1; i < nl; i ++)
        {
            V = (v[i - 1] + v[i + 1] + pow(h, 2) * f[i]) / (2 + sigma * pow(h, 2));
            v_new[i] = v[i] + omega * (V - v[i]);
        }
        for (i = 1; i < nl; i ++)
        {
            e[i] = v_new[i] - v[i];
            v[i] = v_new[i];
            r[i] = f[i] - (- v[i - 1] + (2 + sigma * pow(h, 2)) * v[i] - v[i + 1]) / pow(h, 2);
        }
    }
    void v_gauss_siedel()
    {
        int i;
        vector<double> v_old(nl + 1);
        for (i = 1; i < nl; i ++)
        {
            v_old[i] = v[i];
        }
        for (i = 1; i < nl; i ++)
        {
            v[i] = (v[i - 1] + v[i + 1] + pow(h, 2) * f[i]) / (2 + sigma * pow(h, 2));
            e[i] = v[i] - v_old[i];
        }
        for (i = 1; i < nl; i ++)
        {
            r[i] = f[i] - (- v[i - 1] + (2 + sigma * pow(h, 2)) * v[i] - v[i + 1]) / pow(h, 2);
        }
    }
    
} ;

//Function for relaxation using Weighted Jacobi Method
void relaxation_methods(vector<double>& v, vector<double>& f, int nl, double h)
{
    double V;
    vector<double> v_new(nl + 1);
    int i;
    for (i = 1; i < nl; i ++)
    {
        V = (v[i - 1] + v[i + 1] + pow(h, 2) * f[i]) / (2 + sigma * pow(h, 2));
        v_new[i] = v[i] + omega * (V - v[i]);
    }
    for (i = 1; i < nl; i ++)
    {
        v[i] = v_new[i];
    }
}

//Function for restriction
void restriction_methods(vector<double>& x1, vector<double>& x2, int nl)
{
    int i;
    for (i = 1; i < nl; i ++)
    {
        x1[i] = (x2[2 * i - 1] + 2.0 * x2[2 * i] + x2[2 * i + 1]) / 4.0;
    }
}

//Function for prolongation
void prolongation_methods(vector<double>& x1, vector<double>& x2, int nl)
{
    int i;
    for (i = 0; i <= nl; i ++)
    {
        x2[2 * i] = x1[i];
        x2[2 * i + 1] = (x1[i] + x1[i + 1]) / 2.0; 
    }
}

//Function for V-cycle
void V_cycle(vector<Level>& a, int L, int l)
{
    int i, j, count1 = 1, count2 = 1;
    for (j = l; j < L - 1; j ++)
    {
        if (j != l)
        {
            for (i = 1; i < a[j].nl; i ++)
            {
                a[j].v[i] = 0.0;
            }
        }
        do
        {
            relaxation_methods(a[j].v, a[j].f, a[j].nl, a[j].h);
            count1 ++;
        }while(count1 <= nu1);
        for (i = 1; i < a[j].nl; i ++)
        {
            a[j].r[i] = a[j].f[i] - (- a[j].v[i - 1] + (2 + sigma * pow(a[j].h, 2)) * a[j].v[i] - a[j].v[i + 1]) / pow(a[j].h, 2);
        }
        restriction_methods(a[j + 1].f, a[j].r, a[j + 1].nl);
    }
    a[L - 1].v[1] = (a[L - 1].v[0] + a[L - 1].v[2] + pow(a[L - 1].h, 2) * a[L - 1].f[1]) / (2 + sigma * pow(a[L - 1].h, 2));
    for (j = L - 1; j > l; j --)
    {
        prolongation_methods(a[j].v, a[j - 1].e, a[j].nl);
        for (i = 1; i < a[j - 1].nl; i ++)
        {
            a[j - 1].v[i] = a[j - 1].v[i] + a[j - 1].e[i];
        }
        do
        {
            relaxation_methods(a[j - 1].v, a[j - 1].f, a[j - 1].nl, a[j - 1].h);
            count2 ++;
        }while(count2 <= nu2);
    }
}

//Function for multigrid methods
void MG_methods(vector<Level>& a, int L)
{
    int i;
    V_cycle(a, L, 0); // In this problem V cycle starts from 1st Level i.e. l = 0
    for (i = 1; i < a[0].nl; i ++)
    {
        a[0].r[i] = a[0].f[i] - (- a[0].v[i - 1] + (2 + sigma * pow(a[0].h, 2)) * a[0].v[i] - a[0].v[i + 1]) / pow(a[0].h, 2);
    }
}

//Function for computing error 2-norm and residual 2-norm
int postprocessing_methods(Level l, int count, char option)
{
    int i, conv;
    double error_sum = 0.0, residual_sum = 0.0, error_2_norm, residual_2_norm;
    ofstream fout;
    //Computing error 2-norm
    for (i = 1; i < l.nl; i ++)
    {
        error_sum = error_sum + pow(l.e[i], 2);
    }
    error_2_norm = sqrt(error_sum);
    //Computing residual 2-norm
    for (i = 1; i < l.nl; i ++)
    {
        residual_sum = residual_sum + pow(l.r[i], 2);
    }
    residual_2_norm = sqrt(residual_sum);
    switch(option)
    {
        case 'W':
                fout.open("iterations_vs_residual_2_norm_weighted_jacobi.dat", ios :: app);
                break;
        case 'G':
                fout.open("iterations_vs_residual_2_norm_gauss_siedel.dat", ios :: app);
                break;
        case 'V':
                fout.open("iterations_vs_residual_2_norm_v_cycle.dat", ios :: app);
                break;
        default:
                cout << "Choose an appropriate method for solution" << endl;
                break;
    }
    fout << count << "\t\t" << residual_2_norm << endl;
    fout.close();
    if (residual_2_norm < Tol)
    {
        conv = 1;
    }
    else
    {
        conv = 0;
    }
    return conv;
}

//Function for output solution
void outputdata(Level l, char option)
{
    ofstream fout;
    int i;
    fout.open("Analytical_solution.dat");
    for (i = 0; i <= l.nl; i++)
    {
        fout << i * l.h << "\t\t" << l.u[i] << endl;
    }
    fout.close();
    switch(option)
    {
        case 'W':
                fout.open("Numerical_solution_weighted_jacobi.dat");
                break;
        case 'G':
                fout.open("Numerical_solution_gauss_siedel.dat");
                break;
        case 'V':
                fout.open("Numerical_solution_v_cycle.dat");
                break;
        default:
                cout << "Choose an appropriate method for solution" << endl;
                break;
    }
    for (i = 0; i<= l.nl; i++)
    {
        fout << i * l.h << "\t\t" << l.v[i] << endl;
    }
    fout.close();
}
int main()
{
    int j, l, N, count = 1, L = log2(n), convergence; 
    double h, C = pow(pi * k, 2) + sigma;
    char option;
    vector<Level> a(L);
    for (l = 0; l < L; l ++)
    {
        a[l].set_level_gridpoints(L,l); // Defining the number of grid points after 0 grid point at each level l
        a[l].initialize(); // Initializing the data arrays
        a[l].boundary_conditions();
        a[l].calculate_f(C);
    }
    a[0].analytical_solution();
    cout << "Choose the method for solution(W for Weighted Jacobi, G for Gauss-Siedel, V for V-cycle)" << endl;
    cin >> option;
    do
    {
        cout << "Iteration number " << count << endl;
        switch(option)
        {
            case 'W':
                    a[0].v_weighted_jacobi();
                    break;
            case 'G':
                    a[0].v_gauss_siedel();
                    break;
            case 'V':
                    MG_methods(a, L);
                    break;
            default:
                    cout << "Choose an appropriate method for solution" << endl;
                    break;
        }
        convergence = postprocessing_methods(a[0], count, option);
        if (convergence == 1)
        {
            cout << "Termination condition is satisfied" << endl;
            break;
        }
        count ++;
    } while (count <= MaxIter);
    outputdata(a[0], option);
    return 0;
}