data1=load("Analytical_solution_10.dat");
data2=load("Numerical_solution_v_cycle_with_FMG_10.dat");
figure(1)
plot(data1(:,1),data1(:,2),Marker="*",LineStyle="none");
hold on
plot(data2(:,1),data2(:,2));
title("Solution of 1D Model Problem for k=10");
xlabel("x");
ylabel("u");
legend("Analytical","V-Cycle");
data3=load("iterations_vs_residual_2_norm_v_cycle_with_FMG_10.dat");
figure(2)
plot(log10(data3(:,1)),log10(data3(:,2)));
title("Residual Norm vs Number of Iterations(log-log plot)");
xlabel("Number of iterations");
ylabel("Residual norm");