data1=load("iterations_vs_residual_2_norm_conjugate_gradient.dat");
data2=load("iterations_vs_residual_2_norm_jacobi_conjugate_gradient.dat");
data3=load("iterations_vs_residual_2_norm_ilu_conjugate_gradient.dat");
data4=load("iterations_vs_residual_2_norm_sip_conjugate_gradient.dat");
figure(1)
plot(data1(:,1),log10(data1(:,2)));
hold on
plot(data2(:,1),log10(data2(:,2)),LineStyle="-.");
plot(data3(:,1),log10(data3(:,2)));
plot(data4(:,1),log10(data4(:,2)));
title("Residual 2-Norm vs Number of Iterations(Semi-Log Plot)");
xlabel("Number of iterations");
ylabel("Residual 2-norm");
legend("CG","Jacobi CG","ILU CG","SIP CG");