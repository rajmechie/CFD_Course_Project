% data1 = load ('Temperature_at_x_0.5_sip_conjugate_gradient.dat');
% data2 = load ('Temperature_at_x_0.5_analytical.dat');
% y1= data1(:,1);
% Ty1= data1(:,2);
% y2= data2(:,1);
% Ty2= data2(:,2);
% figure(1)
% plot(Ty1, y1,LineStyle="-");
% hold on
% plot(Ty2, y2,Marker=".",LineStyle="none");
% title("Temperature Variation with y along x = 0.5");
% xlabel("Temperature");
% ylabel("y");
% legend("SIP Conjugate Gradient","Analytical");
data3 = load ('Temperature_at_y_0.5_sip_conjugate_gradient.dat');
data4 = load ('Temperature_at_y_0.5_analytical.dat');
x1= data3(:,1);
Tx1= data3(:,2);
x2= data4(:,1);
Tx2= data4(:,2);
figure(2)
plot(x1,Tx1,LineStyle="--");
hold on
plot(x2,Tx2,LineStyle="-.");
title("Temperature Variation with x along y = 0.5");
xlabel("x");
ylabel("Temperature");
legend("SIP Conjugate Gradient","Analytical");
ylim([0 1.0]);