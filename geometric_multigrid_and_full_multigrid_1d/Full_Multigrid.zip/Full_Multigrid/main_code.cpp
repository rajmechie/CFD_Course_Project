#include <cmath>
#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

#define n 512 //Number of grid points in finest grid after 0 grid point
#define omega 2.0/ 3.0 //Omega for weighted Jacobi Method
#define nu1 2 //Number of iterations in forward phase of V-cycle
#define nu2 2 //Number of iterations in backward phase of V-cycle
#define sigma 1
#define pi 3.141592654
#define k 1 // 1 or 10
#define MaxIter 100
#define Tol 0.000001

// Class of Grid Level
class Level 
{ 
public:
    vector<double> u, v, e, f, r;
    int nl;
    double h;
    void set_level_gridpoints(int L, int l)
    {
        nl = pow(2, L - l);
        h = 1.0 / nl;
    }
    
    // Function to initialize the values of the vectors u, v, e, f, r
    void initialize()
    {
        if (nl == n)
        {
            u.resize(nl + 1, 0.0);
        }
        v.resize(nl + 1, 0.0);
        e.resize(nl + 1, 0.0);
        f.resize(nl + 1, 0.0);
        r.resize(nl + 1, 0.0);
    }
    void boundary_conditions()
    {
        v[0] = v[nl] = 0.0;
    }
    void calculate_f(double C)
    {
        int i;
        for (i = 1; i < nl; i ++)
        {
            f[i] = C * sin(k * pi * i * h);
        }
    }
    void analytical_solution()
    {
        int i;
        for (i = 1; i < nl; i ++)
        {
            u[i] = sin(k * pi * i * h);
        }
    }
    
} ;

//Function for relaxation using Weighted Jacobi Method
void relaxation_methods(vector<double>& v, vector<double>& f, int nl, double h)
{
    double V;
    vector<double> v_new(nl + 1);
    int i;
    for (i = 1; i < nl; i ++)
    {
        V = (v[i - 1] + v[i + 1] + pow(h, 2) * f[i]) / (2 + sigma * pow(h, 2));
        v_new[i] = v[i] + omega * (V - v[i]);
    }
    for (i = 1; i < nl; i ++)
    {
        v[i] = v_new[i];
    }
}

//Function for restriction
void restriction_methods(vector<double>& x1, vector<double>& x2, int nl)
{
    int i;
    for (i = 1; i < nl; i ++)
    {
        x1[i] = (x2[2 * i - 1] + 2.0 * x2[2 * i] + x2[2 * i + 1]) / 4.0;
    }
}

//Function for prolongation
void prolongation_methods(vector<double>& x1, vector<double>& x2, int nl)
{
    int i;
    for (i = 0; i <= nl; i ++)
    {
        x2[2 * i] = x1[i];
        x2[2 * i + 1] = (x1[i] + x1[i + 1]) / 2.0; 
    }
}

//Function for computing residual 2-norm
int postprocessing_methods(Level l, int count)
{
    int i, conv;
    double residual_sum = 0.0, residual_2_norm;
    ofstream fout;
    //Computing residual 2-norm
    for (i = 1; i < l.nl; i ++)
    {
        residual_sum = residual_sum + pow(l.r[i], 2);
    }
    residual_2_norm = sqrt(residual_sum);
    fout.open("iterations_vs_residual_2_norm_v_cycle_with_FMG.dat", ios :: app);
    fout << count << "\t\t" << residual_2_norm << endl;
    fout.close();
    if (residual_2_norm < Tol)
    {
        conv = 1;
    }
    else
    {
        conv = 0;
    }
    return conv;
}

//Function to compute FMG residual 2-norm
void compute_FMG_residual(vector<double>& r, int nl)
{
    double res = 0;
    int i;
    for (i = 1; i < nl; i ++)
    {
        res = res + pow(r[i], 2);
    }
    res = sqrt(res);
    cout << "FMG Residual 2-norm is: " << res << endl;
}

//Function for V-cycle
void V_cycle(vector<Level>& a, int L, int l)
{
    int i, j, count1 = 1, count2 = 1;
    for (j = l; j < L - 1; j ++)
    {
        if (j != l)
        {
            for (i = 1; i < a[j].nl; i ++)
            {
                a[j].v[i] = 0.0;
            }
        }
        do
        {
            relaxation_methods(a[j].v, a[j].f, a[j].nl, a[j].h);
            count1 ++;
        }while(count1 <= nu1);
        for (i = 1; i < a[j].nl; i ++)
        {
            a[j].r[i] = a[j].f[i] - (- a[j].v[i - 1] + (2 + sigma * pow(a[j].h, 2)) * a[j].v[i] - a[j].v[i + 1]) / pow(a[j].h, 2);
        }
        restriction_methods(a[j + 1].f, a[j].r, a[j + 1].nl);
    }
    a[L - 1].v[1] = (a[L - 1].v[0] + a[L - 1].v[2] + pow(a[L - 1].h, 2) * a[L - 1].f[1]) / (2 + sigma * pow(a[L - 1].h, 2));
    for (j = L - 1; j > l; j --)
    {
        prolongation_methods(a[j].v, a[j - 1].e, a[j].nl);
        for (i = 1; i < a[j - 1].nl; i ++)
        {
            a[j - 1].v[i] = a[j - 1].v[i] + a[j - 1].e[i];
        }
        do
        {
            relaxation_methods(a[j - 1].v, a[j - 1].f, a[j - 1].nl, a[j - 1].h);
            count2 ++;
        }while(count2 <= nu2);
    }
}

//Function for FMG-cycle
void FMG(vector<Level>& a, int L)
{
    int i, l;
    for (l = 0; l < L - 1; l ++)
    {
        restriction_methods(a[l + 1].f, a[l].f, a[l + 1].nl);
    }
    a[L - 1].v[1] = (a[L - 1].v[0] + a[L - 1].v[2] + pow(a[L - 1].h, 2) * a[L - 1].f[1]) / (2 + sigma * pow(a[L - 1].h, 2));
    for (l = L - 2; l >= 0; l --)
    {
        prolongation_methods(a[l + 1].v, a[l].v, a[l + 1].nl);
        V_cycle(a, L, l);
    }
    for (i = 1; i < a[0].nl; i ++)
    {
            a[0].r[i] = a[0].f[i] - (- a[0].v[i - 1] + (2 + sigma * pow(a[0].h, 2)) * a[0].v[i] - a[0].v[i + 1]) / pow(a[0].h, 2);
    }
    compute_FMG_residual(a[0].r, a[0].nl);
}

//Function for Multigrid methods
void MG_methods(vector<Level>& a, int L)
{
    int i, count = 1, convergence;
    FMG(a, L);
    do
    {
        cout << "V-cycle Iteration number " << count << endl;
        V_cycle(a, L, 0);
        for (i = 1; i < a[0].nl; i ++)
        {
            a[0].r[i] = a[0].f[i] - (- a[0].v[i - 1] + (2 + sigma * pow(a[0].h, 2)) * a[0].v[i] - a[0].v[i + 1]) / pow(a[0].h, 2);
        }
        convergence = postprocessing_methods(a[0], count);
        if (convergence == 1)
        {
            cout << "Termination condition is satisfied" << endl;
            break;
        }
        count ++;
    } while (count <= MaxIter);
    
}

//Function for output solution
void outputdata(Level l)
{
    ofstream fout;
    int i;
    fout.open("Analytical_solution.dat");
    for (i = 0; i <= l.nl; i++)
    {
        fout << i * l.h << "\t\t" << l.u[i] << endl;
    }
    fout.close();
    fout.open("Numerical_solution_v_cycle_with_FMG.dat"); 
    for (i = 0; i<= l.nl; i++)
    {
        fout << i * l.h << "\t\t" << l.v[i] << endl;
    }
    fout.close();
}
int main()
{
    int j, l, N, L = log2(n); 
    double h, C = pow(pi * k, 2) + sigma;
    vector<Level> a(L);
    for (l = 0; l < L; l ++)
    {
        a[l].set_level_gridpoints(L,l); // Defining the number of grid points after 0 grid point at each level l
        a[l].initialize(); // Initializing the data arrays
        a[l].boundary_conditions();
        a[l].calculate_f(C);
    }
    a[0].analytical_solution();
    MG_methods(a, L);
    outputdata(a[0]);
    return 0;
}